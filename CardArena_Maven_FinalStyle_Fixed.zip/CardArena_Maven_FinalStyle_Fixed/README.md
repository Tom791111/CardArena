# CardArena Maven FinalStyle 修正版

## 重點修正
- 保留上一版登入首頁的運動卡牌風格與排版。
- 保留原 Maven Project 結構。
- 修正 JAR 執行時可能讀不到 `db.properties` 的問題。
- `DBUtil` 會優先讀取 JAR 同層的 `db.properties`，再讀取 classpath。
- `MemberDaoImpl` 登入 SQL 改成 `TRIM(account)` / `TRIM(password)`，降低資料表空白造成登入失敗的機率。
- 登入錯誤會顯示更明確的原因。

## 匯入 Eclipse
File → Import → Maven → Existing Maven Projects → 選擇本資料夾。

## 匯入 MySQL
使用 MySQL Workbench：
File → Open SQL Script → 開啟 `sql/player_card_db.sql` → 點黃色閃電執行。

預設登入：
- 帳號：admin
- 密碼：1234

## 修改資料庫帳密
請修改：
`src/main/resources/db.properties`

若要執行已打包 JAR，也可以修改專案根目錄的：
`db.properties`

## 打包 Fat JAR
Eclipse：
專案右鍵 → Run As → Maven build... → Goals 輸入：

```text
clean package
```

成功後執行：

```text
target/CardArena_Maven_FinalStyle-1.0.0.jar
```

也可以雙擊 `run.bat` 測試。
